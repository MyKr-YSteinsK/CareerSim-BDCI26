# CareerSim-BDCI26 Solution

本提交采用 `Single Agent + Four Skills` 架构，目标是在 48 个月职业模拟中兼顾长期晋升、生存底线、失败恢复和执行成本。

## Runtime architecture

执行链固定为：

```text
fresh observe
→ structured-state-board
→ delivery-progress
→ rolling-planning
→ risk-review
→ preflight
→ take_action
→ fresh observe
```

四个 Skills：

- `structured-state-board`：维护参与者可见事实、正式 Review、重大公开约束及当前 Level 的成长响应。
- `delivery-progress`：维护当前 session 中与 Review 相关的交付生命周期与公开验证证据。
- `rolling-planning`：维护长期晋升主线、Review Window、失败恢复状态和当前唯一候选动作。
- `risk-review`：只审核 Planning 的最终候选，处理重大公开风险，不重做长期规划。

`manifest.json` 保存 evidence firewall、跨 Skill 编排、whole-game persistence、action preflight 与 context recovery 等必须常驻的规则。

## Strategy principles

- 默认 `MODE=A`，优先长期晋升与职业资本积累。
- 低绩效或未晋升本身不触发长期保守；在 `MODE=A` 中修复 progression gap。
- 只有明确重大 survival / safety / job-continuity / trust / compliance / affordability / income-continuity 约束才临时进入 `MODE=S`。
- `MODE=S` 只执行最小必要稳定化；约束解除后立即回到长期主线。
- 正式 Review 是长期规划 checkpoint；良好绩效但未晋升仍代表 promotion readiness 未完成。
- Board 维护当前 Level 下 `Skill / Network / Output` 的 `GAIN / NO_GAIN / UNKNOWN`，用于减少重复投入无效路径，但不推断隐藏 cap。
- 明确公开 risk warning 可触发一次 bounded cleanup；没有新证据不连续避险。
- Review 前优先可兑现的交付和晋升成长，避免为推测性的长期收益牺牲已排期交付。

## Evidence boundary

只使用当前 game session 中参与者可见的公开证据。`HiddenRisk`、hidden counters、internal score、internal event identifiers/effects 以及无法确认公开身份的字段不得进入策略。

## Failure recovery

失败恢复分为：

- `PROGRESSION`：绩效差、未晋升、成长不足；保持 `MODE=A` 并修复晋升路径。
- `RESOURCE`：重大 Health / Dignity / Wealth / 连续性约束；临时 `MODE=S`，最小必要恢复。
- `RISK`：明确公开风险警告；一次 bounded cleanup 后重新进入主线。
- `DELIVERY`：near-checkpoint commitment / result 出现阻塞或不确定性；优先完成、验证或修复交付。

任何 recovery 都必须有退出条件，不能把失败恢复演化为永久保守。

## Resource efficiency

- `ONE FRESH OBSERVE = ONE PLANNING PASS`
- Planning 最多比较两个真正有竞争力的候选。
- Risk 最多允许一次 bounded `RECONSIDER` 分支。
- 普通同-context 流程不在每个动作重读全部 Skills。
- Manifest 保留必要常驻 kernel，详细规则由各 Skill owner 负责。
- 使用 Single Agent，避免多 Agent 协调开销。

## Reproducibility

本提交只包含比赛允许的 manifest、设计材料与四个 Skill 文件，不包含运行日志、Dev 隐藏取证、数据库、密钥或本地环境配置。
