# Skills Design｜技能设计

## 1. Design objective

CareerSim 是一个 48 个月的长程随机决策环境。单次 Story 的局部最优并不足够；系统同时需要：

- 长期晋升一致性；
- 对随机不利事件的恢复能力；
- 生存与职业资本之间的动态权衡；
- 可审计的公开证据边界；
- 有界推理与 Token 开销。

因此采用：

`Single Agent + Four Skills + Structured State + Bounded Risk Gate + Failure Recovery`

没有引入 Team/Swarm、第五 Skill 或跨局 Durable Memory，因为当前没有证据表明它们相对复杂度能稳定增益。

## 2. Skill ownership

### structured-state-board

唯一职责：事实。

输入为 fresh observe、紧邻动作结果以及同局上一版 Board。输出固定的：

- `STATE`
- `REVIEW`
- `PROGRESSION_RESPONSE`
- `STICKY`
- `EFFECTS`
- `UNKNOWN`

它不做策略排序，不执行 Risk gate，不提交动作。

关键设计是 `PROGRESSION_RESPONSE`：

`Skill / Network / Output = GAIN | NO_GAIN | UNKNOWN`

该状态仅基于 clean action→fresh observe 归因，并在 Level 变化后重置。它用于记录当前 Level 的实际边际响应，而不是推断隐藏成长上限。

### delivery-progress

唯一职责：当前 session 的 delivery lifecycle。

最多维护三个 active items，区分：

`OPPORTUNITY / COMMITTED / IN_PROGRESS / BLOCKED / DELIVERY_CLAIMED / DELIVERED / CLOSED`

并区分：

`UNVERIFIED / PUBLICLY_VERIFIED`

工具成功只证明动作执行，不等于职业结果已经兑现。

### rolling-planning

唯一职责：长期战略、Review Window、failure recovery 和 candidate ranking。

维护：

```text
REVIEW_PLAN
MODE = A | S
RECOVERY = NONE | PROGRESSION | RESOURCE | RISK | DELIVERY | UNKNOWN
```

长期主线：

`SURVIVE → PROMOTE → COMPOUND`

第一次 Review 前优先可靠交付和广义成长；Review 后使用公开反馈确定 `Primary Gap`。良好绩效但未晋升仍被视为晋升准备未完成。

### risk-review

唯一职责：最终候选 Risk gate。

普通成长成本直接 `PASS`；重大 survival / job-continuity / trust / compliance / confidentiality / safety / affordability 风险才进入 Full Review。

Risk 不拥有长期规划，不重新排序整局；最多允许 Planning 对一个直接替代候选执行一次 `RECONSIDER`。

## 3. Multi-Skill coordination

固定流水线：

```text
fresh observe
  ↓
Board
  ↓
Delivery
  ↓
Planning
  ↓
Risk
  ↓
preflight
  ↓
take_action
```

这种顺序确保：

1. Planning 使用的是 fresh public state，而不是 stale state；
2. Delivery 先于 Planning，使 near-checkpoint commitment 能进入战略排序；
3. Risk 最后执行，避免 Safety 逻辑反向占领长期规划；
4. 单一 Agent 是唯一 action submitter，消除多提交者竞争。

关键规则允许在 Manifest 与 owning Skill 中重复，以保证 context compression 后仍然显著；重复必须保持相同 owner、trigger 与 exit condition。

## 4. Long-horizon planning

正式 Review 是主要控制 checkpoint。

Planning 不根据单个 Story 任意重写长期目标，而是在每个 Review Window 内维护：

- Long Horizon；
- Primary Gap；
- Next Review Checkpoint。

如果本轮未晋升，则下一周期仍保持 promotion readiness unresolved，并通过 fresh observed progression、delivery evidence 和 formal feedback 调整投入。

## 5. Failure recovery

随机环境无法保证永远走最优路径，因此系统把“失败后能否重新进入竞争轨迹”作为一等目标。

### PROGRESSION

低绩效、未晋升、成长不足。

默认保持 `MODE=A`。重新确定晋升缺口并寻找 still-responsive progression，而不是进入长期保守。

### RESOURCE

明确重大 Health / Dignity / Wealth / affordability / income continuity 约束。

进入 `MODE=S`，但只做最小必要稳定化。约束解除后立即退出 S。

### RISK

公开文本明确表示风险 elevated / accumulating / needs handling，且存在明确 reparative action。

允许一次 bounded cleanup；没有新警告时不连续清理，也不自动进入永久 S。

### DELIVERY

高价值承诺在 Review 前 blocked / delayed / unverified，或当前选择会明确牺牲近端交付确定性。

优先完成、验证或修复真正可在 checkpoint 前兑现的交付。

## 6. Risk control

风险控制强调“真正重大风险”而不是普遍保守。

普通 workload、机会成本、轻微关系摩擦或一般不确定性不能单独否决高价值成长。

只有明确重大约束才进入 Full Review 或 `MODE=S`。即使进入 S，如果 job-continuity threat 本身由绩效或交付失败造成，直接修复绩效/交付仍然可以是最直接的 constraint-relief action。

## 7. Context recovery

只有可观察的 resume / compaction / recovery signal 才进入 recovery：

`same session → fresh observe → reread four Skills → rebuild Board → rebuild Delivery → restore Planning → RECOVERY_READY`

无法可靠恢复的信息写 `UNKNOWN`，不从旧上下文猜测。

## 8. Resource optimization

系统通过以下机制压缩推理成本：

- Single Agent；
- 四 Skill 固定 ownership；
- 普通同-context 不重复加载 Skills；
- one observe / one planning pass；
- 最多两个候选；
- Risk 最多一次 reconsideration；
- Board 与 Delivery 使用 bounded state；
- Manifest 只保留必须常驻的 orchestration 与 critical kernel。

目标是把 Token 和时间花在真正改变决策的 fresh evidence 上，而不是重复解释同一状态。
