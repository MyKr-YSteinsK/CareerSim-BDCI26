# Decision Report｜方案决策报告

## 1. Engineering approach

项目采用：

`Evidence → Hypothesis → Experiment → Decision → Implementation`

公开 Dev 的单局结果只作为证据，不把单次高分当作稳定收益，也不把随机失败自动解释为某个策略的因果结果。

## 2. Key run evidence

已验证历史轨迹包括：

- v6：48 个月，quantitative 75.29，partial 52.70，A，最终 L6；但 runtime adherence 存在缺陷。
- v7o：48 个月，quantitative 71.83，partial 50.28，A，最终 L5；205/205 action 成功，没有 max_continuations。该局证明 whole-game execution persistence 明显改善。
- v7q：M24 自然淘汰，quantitative 26.80，partial 18.76，E，最终 L1；M6/M12/M18 均 C 且未晋升。该坏路径暴露出长期 `MODE=S`、早期 progression deadlock 与 no-gain evidence 生命周期不足。

因此最终设计同时考虑：

- 高分上限；
- 失败路径下限；
- 执行正确性；
- 资源效率。

## 3. Main decisions

### Single Agent + Four Skills

保留单 Agent 唯一动作提交者，避免 Team/Swarm 协调成本和共享状态复杂度。

四个 Skill 分别负责事实、交付、长期规划、最终风险门禁。

### Promotion-first with survival floor

正常状态默认 `MODE=A`，优先晋升与职业资本。

低绩效或未晋升属于 progression failure，不自动进入保守模式。

只有明确重大 survival / safety / job-continuity / trust / compliance / confidentiality / affordability / income-continuity 约束才临时进入 `MODE=S`。

### Structured progression response

为了避免重复把季度资源投入已经观察到无增益的维度，Board 维护当前 Level 下 S/N/O 的：

`GAIN / NO_GAIN / UNKNOWN`

该机制只记录公开事实，不推断 cap。

### Failure recovery

最终策略明确区分：

- `PROGRESSION`
- `RESOURCE`
- `RISK`
- `DELIVERY`

每类恢复都有触发条件、行动原则和退出条件，避免随机坏事件造成永久策略漂移。

### Review-window discipline

Formal Review 是主要长期 checkpoint。

Review 前优先能兑现的成长与交付；Review 结算后不再尝试“补救已发生的 checkpoint”，而是准备下一周期。

### Bounded risk cleanup

公开 risk warning 明确且存在 reparative option 时，可以执行一次 bounded cleanup。没有新证据不连续避险。

## 4. Rejected or deferred mechanisms

以下能力没有进入最终 runtime：

- Team / Swarm；
- 第五 Skill；
- Durable cross-game Memory；
- hidden threshold / hidden Risk reconstruction；
- fixed event-title → choice lookup；
- 固定 promotion month；
- 固定 Skill / Network / Output 数值目标；
- 根据 Dev 隐藏规则硬编码行动。

原因是缺乏足够稳定的实验收益，或泛化风险/复杂度高于已证实价值。

## 5. Resource trade-offs

早期版本曾出现 manifest 与 Skill 规则过度重复、上下文执行碎片化等问题。

最终版本保留必要重复用于 critical-rule salience，但限制：

- one fresh observe = one planning pass；
- 至多两个有效候选；
- Risk 至多一次 reconsideration；
- Board 与 Delivery 有界；
- 普通同-context 不重复读取全部 Skill；
- Single Agent 避免额外通信。

## 6. Known limitations

当前公开 Dev 轨迹具有随机性，且隐藏 Test 分布未知。

最终策略不声称：

- 已证明稳定 80+；
- 已证明隐藏集收益；
- 已知完整 promotion/risk threshold；
- 每次随机 Story 都能选择全局最优答案。

系统设计重点是：

> 在正常路径下保持高成长；在不利路径下能够识别失败类型、执行有界恢复，并重新回到长期晋升主线。
