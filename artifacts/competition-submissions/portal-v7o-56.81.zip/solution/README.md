# Career Compounding Agent

团队：**FZU-Loss快点降**  
提交名称：`career-compounding-v7o-distilled`  
运行方式：JiuwenSwarm `agent` · Single Agent + Four Lean Skills

面向 CareerSim 的 48 个月职业模拟，以**进攻性的长期复利、真实成果兑现和最小必要风险保护**为主线。一个 Agent 连续承担职业决策，四个 Skill 分别维护公开事实、跟踪成果、规划行动和复核风险。

默认 `ADVANCE`：争取高价值主责与关键项目，把工作转化为可验证成果，尽早获得晋升与后续积累机会。正式 Review 后更新方向；重大失败威胁才触发临时 `PROTECT`。每次行动后重新 `observe`，以当前会话证据决定下一步。

## 文件与使用

- [manifest.json](manifest.json)：团队、提交身份与运行总指令。
- [Skills 设计说明](design/skills_design.md)：职责、协同、规划、恢复和资源取舍。
- [决策报告](design/decision_report.md)：最终策略依据与验证边界。
- `skills/*/SKILL.md`：四个运行技能；无附加脚本或本地数据依赖。

ZIP 保留顶层 `solution/`，仅包含上述 8 个提交文件。在已配置的官方 CareerSim 环境中，可对解压目录执行提交与环境校验：

```powershell
python -m career_sim_runner validate --submission solution
```

模型与服务由官方运行环境提供。上述命令同时检查本地实例与服务环境，不能视作纯文件检查。本精修版未新增实跑，历史参考成绩不代表本包或隐藏测试集成绩。
